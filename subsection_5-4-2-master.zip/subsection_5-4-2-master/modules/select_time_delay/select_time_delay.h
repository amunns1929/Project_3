//=====[#include guards - begin]===============================================

#ifndef _SELECT_TIME_DELAY_H_
#define _SELECT_TIME_DELAY_H_

//=====[Declaration of public defines]=========================================

//=====[Declaration of public data types]======================================

//typedef enum {
 // TIME_STATE_3 = 3000,
  //TIME_STATE_6 = 6000,
  //TIME_STATE_8 = 8000
//} TimeState_t;

#include "wipers.h"
extern int SELECTED_TIME_DELAY;
//=====[Declarations (prototypes) of public functions]=========================

void selectTimeDelay();

//=====[#include guards - end]=================================================

#endif // _SELECT_TIME_DELAY_H_
//=====[#include guards - begin]===============================================

#ifndef _USER_INTERFACE_H_
#define _USER_INTERFACE_H_

//=====[Declarations (prototypes) of public functions]=========================

void userInterfaceDisplayInit();
void userInterfaceDisplayUpdate();

//=====[#include guards - end]=================================================

#endif // _USER_INTERFACE_H_